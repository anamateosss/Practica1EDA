#include "Ficheros.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define _GNU_SOURCE

void ImportarFichero(LIBRO **Fichas, WINDOW *Wfichero, bool sumar) {
    FILE *archivo;
    char linea[200];
    char nombreFichero[250];
    struct timeval inicio, fin;
    int numLibrosFichero = 0, numLibrosExistentes = 0;
    int fichasDescartadas = 0;
    int totalLibros = 0;

    // Comprobar si sumar o no
    if (sumar) {
        if (Estadisticas.NumeroFichas == 0) {
            mvwprintw(Wfichero, 1, 1, "ERROR: No hay fichas para sumar. Debes importar primero.");
            wrefresh(Wfichero);
            return;
        }
        numLibrosExistentes = Estadisticas.NumeroFichas;
    } else {
        if (Estadisticas.NumeroFichas != 0) {
            mvwprintw(Wfichero, 1, 1, "ERROR: Ya existen libros. Use 'sumar' para agregar.");
            wrefresh(Wfichero);
            return;
        }
    }

    // Limpiar la ventana y solicitar el nombre del fichero
    werase(Wfichero);
    box(Wfichero, 0, 0);
    mvwprintw(Wfichero, 1, 1, "Introduzca el nombre del fichero a importar/sumar: ");
    wrefresh(Wfichero);

    echo();
    wgetnstr(Wfichero, nombreFichero, sizeof(nombreFichero));
    noecho();

    // Mostrar el nombre del fichero capturado
    mvwprintw(Wfichero, 3, 1, "Fichero capturado: %s", nombreFichero);
    wrefresh(Wfichero);

    // Abrir el fichero
    archivo = fopen(nombreFichero, "r");
    if (!archivo) {
        mvwprintw(Wfichero, 2, 1, "ERROR: No se pudo abrir el fichero.");
        wrefresh(Wfichero);
        return;
    }

    gettimeofday(&inicio, NULL);

    // Contar el número de libros en el fichero
    while (fgets(linea, sizeof(linea), archivo)) {
        numLibrosFichero++;
    }
    rewind(archivo);

    // Verificar si el fichero tiene contenido
    if (numLibrosFichero <= 1) {
        mvwprintw(Wfichero, 3, 1, "ERROR: El fichero no contiene libros.");
        fclose(archivo);
        wrefresh(Wfichero);
        return;
    }

    // Redimensionar memoria para el array de libros
    totalLibros = numLibrosExistentes + (numLibrosFichero - 1);
    *Fichas = realloc(*Fichas, totalLibros * sizeof(LIBRO));
    if (!*Fichas) {
        mvwprintw(Wfichero, 4, 1, "Error: No se pudo asignar memoria para las fichas.");
        fclose(archivo);
        wrefresh(Wfichero);
        return;
    }

    // Descartar la cabecera
    fgets(linea, sizeof(linea), archivo);

    // Leer y procesar cada línea
    int indiceLibro = numLibrosExistentes;
    while (fgets(linea, sizeof(linea), archivo)) {
        char *Titulo = NULL, *ApellAutor = NULL, *NomAutor = NULL, *Genero = NULL;
        char *Editorial = NULL, *Coleccion = NULL;
        char *lineaCopia = strdup(linea);

        if (!lineaCopia) {
            continue;
        }

        Titulo = strsep(&lineaCopia, ",");
        ApellAutor = strsep(&lineaCopia, ",");
        NomAutor = strsep(&lineaCopia, ",");
        Genero = strsep(&lineaCopia, ",");
        Editorial = strsep(&lineaCopia, ",");
        Coleccion = strsep(&lineaCopia, "\n");

        if (!Titulo || !ApellAutor) {
            fichasDescartadas++;
            free(lineaCopia);
            continue;
        }

        (*Fichas)[indiceLibro].Titulo = strdup(Titulo);
        (*Fichas)[indiceLibro].ApellAutor = strdup(ApellAutor);
        (*Fichas)[indiceLibro].NomAutor = NomAutor ? strdup(NomAutor) : strdup("Desconocido");
        (*Fichas)[indiceLibro].Genero = Genero ? strdup(Genero) : strdup("Desconocido");
        (*Fichas)[indiceLibro].Editorial = Editorial ? strdup(Editorial) : strdup("Desconocida");
        (*Fichas)[indiceLibro].Coleccion = Coleccion ? strdup(Coleccion) : strdup("Sin colección");

        free(lineaCopia);
        indiceLibro++;
    }

    fclose(archivo);

    gettimeofday(&fin, NULL);
    double tiempoTranscurrido = (fin.tv_sec - inicio.tv_sec) + (fin.tv_usec - inicio.tv_usec) / 1E6;

    // Actualizar estadísticas globales
    Estadisticas.NumeroFichas = totalLibros;
    Estadisticas.FichasDescartadas += fichasDescartadas;

    // Mostrar estadísticas en la ventana
    werase(Wfichero);
    box(Wfichero, 0, 0);
    mvwprintw(Wfichero, 1, 1, "Importación completada.");
    mvwprintw(Wfichero, 2, 1, "Fichero: %s", nombreFichero);
    mvwprintw(Wfichero, 3, 1, "Libros importados: %d", totalLibros - numLibrosExistentes);
    mvwprintw(Wfichero, 4, 1, "Fichas descartadas: %d", fichasDescartadas);
    mvwprintw(Wfichero, 5, 1, "Tiempo de procesamiento: %.2f segundos", tiempoTranscurrido);
    mvwprintw(Wfichero, 7, 1, "Pulse una tecla para continuar...");
    
    wrefresh(Wfichero);
    getch();  // Esperar que el usuario pulse una tecla

    // Limpiar la ventana para el siguiente menú
    werase(Wfichero);
    box(Wfichero, 0, 0);
    mvwprintw(Wfichero, 1, 1, "Seleccione una opción:");
    mvwprintw(Wfichero, 2, 1, "4 - Buscar por título");
    mvwprintw(Wfichero, 3, 1, "5 - Estadísticas");
    mvwprintw(Wfichero, 4, 1, "6 - Refrescar");
    mvwprintw(Wfichero, 5, 1, "7 - Salir");
    wrefresh(Wfichero);
}
