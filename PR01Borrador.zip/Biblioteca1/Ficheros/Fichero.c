#include "Ficheros.h"

void Fichero(LIBRO **Fichas, int OpcionMenu) {
    static WINDOW *Wfichero = NULL;

    // Si es la primera vez que se accede a esta ventana, se dibuja
    if (Wfichero == NULL) {
        Wfichero = newwin(10, 80, 5, 2); // Cambié el tamaño a 10x80 para más espacio
        if (Wfichero == NULL) {
            perror("Error al crear la ventana de gestión de ficheros.");
            return;
        }
        box(Wfichero, 0, 0);  // Crear un borde en la ventana
        wrefresh(Wfichero);   // Asegurar que se refresque la ventana al crearse
        DibujarGestionFichero(Wfichero);
    }

    // Limpiar los datos de la ventana para evitar mensajes superpuestos
    werase(Wfichero);  // Limpia toda la ventana
    box(Wfichero, 0, 0); // Redibujar el borde después de limpiar
    DibujarGestionFichero(Wfichero); // Redibuja la estructura de la ventana

    // Mensaje informativo en la parte superior
    mvwprintw(Wfichero, 1, 1, "Gestion de Ficheros - Opcion seleccionada: %d", OpcionMenu);
    mvwprintw(Wfichero, 2, 1, "-------------------------------------------");

    // Se invoca la función correspondiente según la opción de menú seleccionada
    switch (OpcionMenu) {
        case 21:    // Importar un fichero a una lista nueva
            mvwprintw(Wfichero, 3, 1, "Opcion: Importar un fichero en una lista nueva");
            mvwprintw(Wfichero, 4, 1, "Por favor, introduzca el nombre del fichero:");
            wrefresh(Wfichero);  // Refrescar para mostrar mensaje antes de capturar el nombre
            ImportarFichero(Fichas, Wfichero, false); // Cambiado a false para indicar nueva importación
            break;

        case 22:    // Sumar los libros de un fichero a una lista existente
            mvwprintw(Wfichero, 3, 1, "Opcion: Sumar libros de un fichero a la lista existente");
            mvwprintw(Wfichero, 4, 1, "Por favor, introduzca el nombre del fichero:");
            wrefresh(Wfichero);  // Refrescar para mostrar mensaje antes de capturar el nombre
            ImportarFichero(Fichas, Wfichero, true);
            break;

        case 23:    // Exportar la lista de libros a un fichero
            mvwprintw(Wfichero, 3, 1, "Opcion: Exportar la lista de libros a un fichero");
            mvwprintw(Wfichero, 4, 1, "Por favor, introduzca el nombre del fichero para exportar:");
            wrefresh(Wfichero);  // Refrescar para mostrar mensaje antes de capturar el nombre
            ExportarFichero(Fichas, Wfichero);
            break;

        case 24:    // Eliminar la lista de libros existente
            mvwprintw(Wfichero, 3, 1, "Opcion: Eliminar la lista de libros existente");
            mvwprintw(Wfichero, 4, 1, "Esta accion es irreversible. Continuar? (y/n):");
            wrefresh(Wfichero);  // Refrescar para mostrar mensaje antes de continuar
            DescartarFichero(Fichas, Wfichero); // Asegúrate de que esta función maneje la confirmación
            break;

        default:
            mvwprintw(Wfichero, 3, 1, "Opcion no valida. Por favor seleccione una opcion valida.");
            break;
    }

    // Refrescar ventana después de realizar la operación
    wrefresh(Wfichero);
    return;
}
