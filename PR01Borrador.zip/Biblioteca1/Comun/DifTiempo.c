/*****************************************
 * Nombre: DifTiempo
 * Argumentos: struct timeval inicio:   Tiempo de inicio
 *             struct timeval fin:      Tiempo de fin
 * Descripción: Calcula los microsegundos de diferencia entre ambos tiempos
 * Reglas de uso: 
 * Código de Retorno: Microsegundos de diferencia
 * Programador: JMSM (Sept-24)
 *****************************************/

#include "Comun.h"

int DifTiempo(struct timeval inicio,struct timeval fin)
{
    
    // Codigo del alumno
    
}