/*****************************************
 * Nombre: ImortarFichero
 * Argumentos: LIBRO **Fichas:   Puntero al array de libros
 *             WINDOW *Wfichero: Ventana para capturar el nombre del fichero
 *             bool sumar:       Si es true las fichas de libros se añaden a las existentes,
 *                               si es false la lista de libros tiene que estar vacía.
 * Descripción: Lee el nombre del fichero que contendrá los datos a importar. Carga los libros del fichero
 *              en el array de libros, dimensionándolo si es necesario y descartando los que no tengan título o autor.
 * Reglas de uso: 
 * Código de Retorno:
 * Programador: JMSM (Sept-24)
 *****************************************/

#include "Ficheros.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#define _GNU_SOURCE


void ImportarFichero(LIBRO **Fichas,WINDOW *Wfichero,bool sumar)
{
   
    FILE *archivo;
    char linea[200];
    int i;
    char nombreFichero[250];
    struct timeval inicio, fin;
    int numLibrosFichero = 0, numLibrosExistentes = 0;
    int fichasDescartadas = 0;
    int totalLibros = 0;

     if (sumar) 
     {
        if (Estadisticas.NumeroFichas == 0) 
        {
            mvwprintw(Wfichero, 1, 1, "ERROR");
            mvwprintw(Wfichero, 1, 2, "No hay ficheros para sumar, debes importarlo");
            wrefresh(Wfichero);
            return;
        }
       numLibrosExistentes=Estadisticas.NumeroFichas;

    }  
    else {
        if (Estadisticas.NumeroFichas != 0) {
            mvwprintw(Wfichero, 1, 1, "ERROR Ya existen libros");
            mvwprintw(Wfichero, 1, 2, "Use la opción de 'sumar' para agregar");
            wrefresh(Wfichero);
            return;
        }
    }
    werase(Wfichero);
    mvwprintw(Wfichero, 1, 1, "Introduzca el nombre del fichero a importar/sumar: ");
    echo(); // Habilitar echo para permitir entrada de texto
    wgetnstr(Wfichero, nombreFichero, sizeof(nombreFichero));
    noecho(); // Deshabilitar echo nuevamente

    
    archivo = fopen(nombreFichero, "r");
    if (!archivo) {
        mvwprintw(Wfichero, 2, 1, "ERROR");
        mvwprintw(Wfichero, 2, 2, "No se pudo abrir el fichero");
        wrefresh(Wfichero);
        return;
    }

    gettimeofday(&inicio, NULL);

     while (fgets(linea, sizeof(linea), archivo)) 
    {
        numLibrosFichero++;
    }
    rewind(archivo);

    if (numLibrosFichero <= 1) {
        mvwprintw(Wfichero, 3, 1, "ERROR");
          mvwprintw(Wfichero, 3, 2, "El fichero no contiene nada");
        fclose(archivo);
        wrefresh(Wfichero);
        return;
    }

    totalLibros = numLibrosExistentes + (numLibrosFichero - 1); 
    *Fichas = realloc(*Fichas, totalLibros * sizeof(LIBRO));
    if (!*Fichas) {
        mvwprintw(Wfichero, 4, 1, "Error: No se pudo asignar memoria para las fichas.");
        fclose(archivo);
        wrefresh(Wfichero);
        return;
    }

    fgets(linea, sizeof(linea), archivo);

   // Leer las líneas del fichero (cada línea es un libro)
int indiceLibro = numLibrosExistentes;
while (fgets(linea, sizeof(linea), archivo)) {
    char *Titulo = NULL, *ApellAutor = NULL, *NomAutor = NULL, *Genero = NULL;
    char *Editorial = NULL, *Coleccion = NULL;
    char *lineaCopia = strdup(linea);  // Crear una copia de la línea

    if (!lineaCopia) {
        // Si no se puede asignar memoria para la copia, continuar con la siguiente línea
        continue;
    }

    Titulo = strsep(&lineaCopia, ",");
    ApellAutor = strsep(&lineaCopia, ",");
    NomAutor = strsep(&lineaCopia, ",");
    Genero = strsep(&lineaCopia, ",");
    Editorial = strsep(&lineaCopia, ",");
    Coleccion = strsep(&lineaCopia, "\n");

    // Validar que el título y el apellido del autor no sean NULL
    if (!Titulo || !ApellAutor) {
        fichasDescartadas++;
        free(lineaCopia);  // Liberar la copia antes de continuar
        continue;
    }

    // Asignar espacio dinámico para los campos del libro
    (*Fichas)[indiceLibro].Titulo = strdup(Titulo);
    (*Fichas)[indiceLibro].ApellAutor = strdup(ApellAutor);
    (*Fichas)[indiceLibro].NomAutor = NomAutor ? strdup(NomAutor) : strdup("Desconocido");
    (*Fichas)[indiceLibro].Genero = Genero ? strdup(Genero) : strdup("Desconocido");
    (*Fichas)[indiceLibro].Editorial = Editorial ? strdup(Editorial) : strdup("Desconocida");
    (*Fichas)[indiceLibro].Coleccion = Coleccion ? strdup(Coleccion) : strdup("Sin colección");

    // Liberar la copia de la línea
    free(lineaCopia);

    // Incrementar el índice del libro
    indiceLibro++;
}


    fclose(archivo);

    // Capturar tiempo de fin
    gettimeofday(&fin, NULL);
    double tiempoTranscurrido = (fin.tv_sec - inicio.tv_sec) + (fin.tv_usec - inicio.tv_usec) / 1E6;

    // Actualizar las estadísticas globales
    Estadisticas.NumeroFichas = totalLibros;
    Estadisticas.FichasDescartadas += fichasDescartadas;

    // Mostrar estadísticas en la ventana
    mvwprintw(Wfichero, 5, 1, "Importación completada.");
    mvwprintw(Wfichero, 6, 1, "Libros importados: %d", totalLibros - numLibrosExistentes);
    mvwprintw(Wfichero, 7, 1, "Fichas descartadas: %d", fichasDescartadas);
    mvwprintw(Wfichero, 8, 1, "Tiempo de procesamiento: %.2f segundos", tiempoTranscurrido);
    wrefresh(Wfichero);
   
 

    
      

        
}